﻿namespace Ex04.Menus.Interfaces
{

    public interface IInvoker
    {
        void Invoke();
    }
}
