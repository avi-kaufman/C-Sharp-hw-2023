﻿namespace Ex03.ConsoleUI
{
    internal class program
    {
        public static void Main()
        {
            ConsoleUI.UI();
        }
    }
}